# RailMate — AI Train Travel Agent (Frontend Demo)

Responsive HTML/CSS/JavaScript internship final project. Includes sample train search, validated passenger form, demo booking, browser-local booking storage, edit/delete, downloadable **text** tickets and an offline rule-based travel assistant.

**Important:** All routes, times, fares and confirmations are fictional sample data. No real bookings, live train information, payments or generative AI integration. Tickets are not valid for travel.

## Run locally
Open `index.html` in a browser, or use VS Code Live Server. No dependencies or Python backend required.

## Sample routes
Nagpur → Mumbai; Pune → Nagpur; Delhi → Bengaluru; Delhi → Bhopal.

## Deploy with GitHub Pages
1. Create a public GitHub repository.
2. Push these files with `index.html` at repository root.
3. Open Settings → Pages → Deploy from a branch → main → /(root) → Save.
4. Open the published Pages URL and test on desktop and mobile.

## Git commands
```bash
git init
git status
git add .
git commit -m "Initial responsive train travel website"
git log
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/AI-Train-Travel-Agent.git
git push -u origin main
```
Replace `YOUR-USERNAME`. Take your own Git command screenshots for submission. Make further meaningful commits as you improve the project.

## Tech
Semantic HTML5, CSS3 Flexbox/Grid/media queries, vanilla JavaScript, DOM events, form validation, arrays/objects, filtering, localStorage, Blob downloads.

## Project links
- Repository: ADD YOUR REAL REPOSITORY URL
- Live site: ADD YOUR REAL GITHUB PAGES URL

## Documentation
See `PROJECT-REPORT.pdf`. Add real screenshots to the `screenshots/` directory after running the site.
